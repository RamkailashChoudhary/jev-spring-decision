package dev.danvega.hellojev;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("jev")
public record JevProperties(String apiKey, String baseUrl, String model) {
}
