package dev.danvega.hellojev;

import java.util.Map;

public record JevRequest(Object state, String model, Map<String, Question> questions) {
}
