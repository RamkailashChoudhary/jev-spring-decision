package dev.danvega.hellojev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties(JevProperties.class)
public class HelloJevApplication {

    static void main(String[] args) {
        SpringApplication.run(HelloJevApplication.class, args);
    }

}
