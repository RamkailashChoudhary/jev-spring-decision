package dev.danvega.hellojev;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record Question(Type type, String instructions, Object criteria) {

    public static Question noul(String instructions) {
        return new Question(Type.NOUL, instructions, null);
    }

    public static Question choice(String instructions, Map<String, String> options) {
        return new Question(Type.CHOICE, instructions, options);
    }

    public static Question score(String instructions, List<String> levels) {
        return new Question(Type.SCORE, instructions, levels);
    }

    public enum Type {
        NOUL, CHOICE, SCORE;

        @JsonValue
        public String json() {
            return name().toLowerCase();
        }
    }
}
