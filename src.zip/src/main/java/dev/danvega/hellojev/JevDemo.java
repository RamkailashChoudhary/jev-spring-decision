package dev.danvega.hellojev;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;

@Component
public class JevDemo implements CommandLineRunner {

    private final JevClient jev;
    private final JevProperties properties;

    public JevDemo(JevClient jev, JevProperties properties) {
        this.jev = jev;
        this.properties = properties;
    }

    @Override
    public void run(String... args) {
        if (!StringUtils.hasText(properties.apiKey())) {
            System.out.println("Set TYPESAFE_API_KEY to run the sample.");
            return;
        }

        var state = "Hi, I've been trying to connect my Stripe account for 3 days and it keeps failing. "
                + "I'm losing sales. Please help ASAP.";

        var questions = Map.of(
                "is_urgent", Question.noul("Does this message express urgency?"),
                "department", Question.choice("Which team should handle this?", Map.of(
                        "billing", "Charges, invoices, payment problems",
                        "integrations", "Connecting third-party services such as Stripe",
                        "shipping", "Delivery status, delays, lost packages")),
                "severity", Question.score("How severe is the reported issue?", List.of(
                        "Cosmetic; no impact to functionality",
                        "Broken or degraded feature, but a workaround exists",
                        "Blocking issue; no workaround exists")));

        var response = jev.evaluate(state, questions);

        System.out.println("Model: " + response.model());
        response.answers().forEach((id, answer) -> System.out.println(id + ": " + describe(answer)));
        System.out.println("Usage: " + response.usage());
    }

    private String describe(JevResponse.Answer answer) {
        return switch (answer.type()) {
            case NOUL -> "noul %.2f".formatted(answer.noul());
            case CHOICE -> "choice %s (confidence %.2f) %s"
                    .formatted(answer.choice(), answer.confidence(), answer.probabilities());
            case SCORE -> "score %.2f (confidence %.2f) %s"
                    .formatted(answer.score(), answer.confidence(), answer.legend());
        };
    }
}
