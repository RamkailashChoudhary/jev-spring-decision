package dev.danvega.hellojev;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

public record JevResponse(String model, Map<String, Answer> answers, Usage usage) {

    /**
     * Which fields are present depends on the question type:
     * noul -> noul, choice -> choice + probabilities + confidence, score -> score + legend + probabilities + confidence.
     */
    public record Answer(
            Question.Type type,
            Double noul,
            String choice,
            Double score,
            Double confidence,
            Map<String, Double> probabilities,
            Map<String, String> legend) {
    }

    public record Usage(@JsonProperty("input_tokens") int inputTokens,
                        @JsonProperty("output_tokens") int outputTokens) {
    }
}
